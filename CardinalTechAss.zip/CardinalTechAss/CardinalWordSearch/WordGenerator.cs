﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CardinalWordSearch
{
    public class WordGenerator
    {
        public async Task<List<string>> GenerateRandomWord()
        {
            var words = new List<string>();

            //206092520Ss
            try
            {
                int alphabetLettersCount = 25;
                char[] letters = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
                Random rand = new Random();

                //Create the random word:
                for (int i = 1; i <= 1; i++)
                {
                    string word = "";
                    for (int j = 1; j <= alphabetLettersCount; j++)
                    {
                        // Pick a random number between 0 and 25
                        // to select a letter from the letters array.
                        int letter_num = rand.Next(0, letters.Length - 1);

                        // Append the letter.
                        word += letters[letter_num];
                    }

                    words.Add(word);
                }
            }
            catch (Exception ex)
            {
                var error = "Error Occured when getting words: " + ex.Message;
                Console.WriteLine(error);
                Console.WriteLine("Press 'Enter' to exit");
                Console.ReadLine();
                Environment.Exit(1);
            }

            return words;
        }
    }
}
