﻿using System;

namespace CardinalWordSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            //get words from dictionary (words.txt)
            var wordsList = new ReadDictionary().GetWords();

            //Create words grid
            var randomWord = new WordGenerator().GenerateRandomWord();

            //Display grid
            var Display = new DisplayGrid().DisplayGridWords(randomWord.Result);

            //2D array of Grid
            var _2DArrayBoggle = new DisplayGrid().Create2DBoard(randomWord.Result);

            Console.WriteLine("Searching... \n");
            var searchResults = new BoggleDfs().FindWordsInGrid(wordsList.Result,_2DArrayBoggle.Result);
        }
    }
}
