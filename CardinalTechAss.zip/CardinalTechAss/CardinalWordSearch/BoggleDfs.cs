﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardinalWordSearch
{
    public class BoggleDfs
    {
        private List<string> _list = new List<string>();
        public bool FindWordsInGrid(List<string> _dictionary, char[,] _boggle)
        {
            string[] dictionary = _dictionary.ToArray();
            char[,] boggle = _boggle;

            FindWords(boggle, dictionary);
            string[] expected = _dictionary.ToArray();
            
            return true;
        }

        private void FindWords(char[,] boggle, string[] dictionary)
        {
            bool[,] visited = new bool[boggle.GetLength(0), boggle.GetLength(1)];
            StringBuilder str = new StringBuilder();
            //run DFS for all the options and compare with the dictionary
            for (int i = 0; i < boggle.GetLength(0); i++)
            {
                for (int j = 0; j < boggle.GetLength(1); j++)
                {
                    DFS(i, j, boggle, dictionary, str, visited);
                }
            }
        }

        
        //This entire below method (DFS) was taken as is from web and not changed!
        private void DFS(int i, int j, char[,] boggle, string[] dictionary, StringBuilder str, bool[,] visited)
        {
            //mark we already visited this vertex
            visited[i, j] = true;

            str.Append(boggle[i, j]);
            if (IsWord(str.ToString(), dictionary))
            {
                _list.Add(str.ToString());
                Console.WriteLine(str.ToString());
            }

            for (int row = i - 1; row <= i + 1 && row < boggle.GetLength(0); row++)
            {
                for (int col = j - 1; col <= j + 1 && col < boggle.GetLength(1); col++)
                {
                    if (col >= 0 && row >= 0 && !visited[row, col])
                    {
                        DFS(row, col, boggle, dictionary, str, visited);
                    }
                }
            }

            visited[i, j] = false;
            str.Remove(str.Length - 1, 1);
        }

        private bool IsWord(string str, string[] dictionary)
        {
            for (int i = 0; i < dictionary.Length; i++)
            {
                if (string.CompareOrdinal(str, dictionary[i]) == 0)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
