﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CardinalWordSearch
{
    public class DisplayGrid
    {
    public async Task<bool> DisplayGridWords(List<string> words)
    {
            var count = 0;
            Console.WriteLine("Grid:");
            Console.WriteLine("");

            foreach (var letter in words[0])
            {
                Console.Write(letter + "|");
                count++;
                if (count == 5 || count == 10 || count == 15 || count == 20)
                {
                    Console.WriteLine("");
                }
            }
            Console.WriteLine("\n \n");
            return true;
     }


        public async Task<char[,]> Create2DBoard(List<string> words)
        {
            var wordsList = new List<string>();
            foreach (var letter in words[0])
            {
                wordsList.Add(letter.ToString());
            }
            var _1 = Convert.ToChar(wordsList[0]);
            var _2 = Convert.ToChar(wordsList[1]);
            var _3 = Convert.ToChar(wordsList[2]);
            var _4 = Convert.ToChar(wordsList[3]);
            var _5 = Convert.ToChar(wordsList[4]);
            var _6 = Convert.ToChar(wordsList[5]);
            var _7 = Convert.ToChar(wordsList[6]);
            var _8 = Convert.ToChar(wordsList[7]);
            var _9 = Convert.ToChar(wordsList[8]);
            var _10 = Convert.ToChar(wordsList[9]);
            var _11 = Convert.ToChar(wordsList[10]);
            var _12 = Convert.ToChar(wordsList[11]);
            var _13 = Convert.ToChar(wordsList[12]);
            var _14 = Convert.ToChar(wordsList[13]);
            var _15 = Convert.ToChar(wordsList[14]);
            var _16 = Convert.ToChar(wordsList[15]);
            var _17 = Convert.ToChar(wordsList[16]);
            var _18 = Convert.ToChar(wordsList[17]);
            var _19 = Convert.ToChar(wordsList[18]);
            var _20 = Convert.ToChar(wordsList[19]);
            var _21 = Convert.ToChar(wordsList[20]);
            var _22 = Convert.ToChar(wordsList[21]);
            var _23 = Convert.ToChar(wordsList[22]);
            var _24 = Convert.ToChar(wordsList[23]);
            var _25 = Convert.ToChar(wordsList[24]);

            char[,] _2DgridArray = {{_1, _2, _3,_4,_5},
                              {_6, _7, _8,_9,_10},
                              {_11, _12, _13,_14,_15},
                              {_16, _7, _18,_19,_20},
                              { _21, _22, _23,_24,_25}};


            return _2DgridArray;
        }
    }
}
