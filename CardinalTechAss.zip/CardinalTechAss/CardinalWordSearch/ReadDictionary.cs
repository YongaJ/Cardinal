﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CardinalWordSearch
{
    public class ReadDictionary
    {
        public async Task<List<string>> GetWords() 
        {
            var words = new List<string>();

            try
            {
                string word;
                int lineCounter = 0;

                System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\magaf\OneDrive\Documents\CardinalTechAss\Technical Interview Test\words.txt");
                while ((word = file.ReadLine()) != null)
                {
                    words.Add(word.Trim());
                    lineCounter++;
                }

                file.Close();
                return words;
            }
            catch (Exception ex)
            {
                words.Clear();
                words.Add(ex.Message.ToString());
                var error = "Error Occured when getting words: " + words[0].ToString();
                Console.WriteLine(error);
                Console.WriteLine("Press 'Enter' to exit");
                Console.ReadLine();
                Environment.Exit(1);
                return words;
            }
            
        }
    }
}
